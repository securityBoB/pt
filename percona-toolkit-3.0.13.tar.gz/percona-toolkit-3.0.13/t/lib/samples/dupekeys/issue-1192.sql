CREATE TABLE `issue_1192` (
  `a` int(11) NOT NULL DEFAULT '0',
  `B` int(11) DEFAULT NULL,
  PRIMARY KEY (`a`),
  KEY `a` (`a`),
  KEY `B` (`B`)
) ENGINE=InnoDB;
