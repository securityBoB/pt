CREATE TABLE `issue_131_sel` (
  `id` int(11) default NULL,
  `foo` varchar(16) default NULL,
  `name` varchar(16) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1
