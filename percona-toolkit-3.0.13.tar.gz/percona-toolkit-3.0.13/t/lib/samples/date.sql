CREATE TABLE `checksum_test_5` (
  `a` date NOT NULL,
  `b` int(11) default NULL,
  PRIMARY KEY  (`a`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
