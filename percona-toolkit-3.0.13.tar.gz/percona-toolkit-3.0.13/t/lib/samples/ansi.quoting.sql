CREATE TABLE "t" (
  "a" int(11) DEFAULT NULL,
  "b`c" int(11) DEFAULT NULL,
  "d""e" int(11) DEFAULT NULL,
  "f
g" int(11) DEFAULT NULL,
  "h\" int(11) DEFAULT NULL,
  "i\""" int(11) DEFAULT NULL
)
