DROP TABLE IF EXISTS `issue_331_t1`;
CREATE TABLE `issue_331_t1` (
  `t1_id` bigint(20) NOT NULL default '0',
  `bar` bigint(20) NOT NULL default '0',
  PRIMARY KEY  (`t1_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
