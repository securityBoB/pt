CREATE TABLE `t` (
  `i` int(11) default NULL,
  `J` int(11) default NULL,
  KEY `Foo_Bar` (`i`,`J`)
) ENGINE=InnoDB
