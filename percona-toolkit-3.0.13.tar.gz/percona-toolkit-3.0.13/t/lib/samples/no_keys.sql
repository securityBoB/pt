CREATE TABLE `t1` (
  `a` int(11) NOT NULL,
  `b` char(50) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
