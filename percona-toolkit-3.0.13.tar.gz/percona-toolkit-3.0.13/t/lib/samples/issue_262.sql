DROP DATABASE IF EXISTS `my db`;
CREATE DATABASE `my db`;
USE `my db`;
CREATE TABLE `my tbl` (
   i INT
);
