mysql> show create table checksum_test_10\G
*************************** 1. row ***************************
       Table: checksum_test_10
Create Table: CREATE TABLE `checksum_test_10` (
  `a` decimal(10,0) NOT NULL,
  PRIMARY KEY  (`a`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1
1 row in set (0.00 sec)

mysql> notee
