CREATE TABLE `issue_132` (
  `country` enum('','Cote D`ivoire') default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1
