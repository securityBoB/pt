CREATE TABLE `t2` (
  `a` int(11) NOT NULL,
  `b` char(50) default NULL,
  PRIMARY KEY  (`a`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
