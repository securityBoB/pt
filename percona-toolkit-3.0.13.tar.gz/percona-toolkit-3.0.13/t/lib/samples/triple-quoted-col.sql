CREATE TABLE `t` (
  `foo` int(11) DEFAULT NULL,
  ```bar``` int(11) DEFAULT NULL
) ENGINE=InnoDB
