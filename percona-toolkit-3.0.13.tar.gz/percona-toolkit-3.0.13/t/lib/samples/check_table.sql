DROP DATABASE IF EXISTS test;
CREATE DATABASE test;
USE test;
CREATE TABLE t (
  i int
);
CREATE TABLE `t_` (
  i int
);
CREATE TABLE ta (
  i int
);
CREATE TABLE `t%` (
  i int
);
CREATE TABLE `t%_` (
  i int
);
