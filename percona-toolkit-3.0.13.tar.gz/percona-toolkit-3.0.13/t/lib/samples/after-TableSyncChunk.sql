use test;

drop table if exists test1,test2,test3,test4,test5;
