CREATE TABLE `rental` (
  `rental_id` int(11) NOT NULL auto_increment,
  `foo` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8
