CREATE TABLE `issue_131_sel` (
  `name` varchar(16) default NULL,
  `id` int(11) default NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1
